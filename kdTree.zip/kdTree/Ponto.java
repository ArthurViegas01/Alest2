public class Ponto{
    public String Rotulo;
    public int x = 0;
    public int y = 0;
    public Ponto esq;
    public Ponto dir;

    public Ponto(String Rotulo, int x, int y){
        this.Rotulo = Rotulo;
        this.x = x;
        this.y = y;
    }

    @Override
    public String toString(){
        return Rotulo + "(x = " + x +", y = " + y +')';
    }   
}