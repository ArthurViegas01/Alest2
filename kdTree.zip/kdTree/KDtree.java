public class KDtree{

    public Ponto raiz;

    public void AdicionarPonto(String Rotulo, int x, int y){
        Ponto p = new Ponto(Rotulo ,x ,y);
        Ponto aux = raiz;
        
        int coordenada_ponto,coordenada_nodo;
        boolean continua = true;
    
        int nivel = 0;


        if (raiz == null){
            raiz = p;
        }else{


            while(continua){
                if(nivel % 2 == 0){

                    coordenada_ponto = p.x;
                    coordenada_nodo = aux.x;
                }else{

                    coordenada_ponto = p.y;
                    coordenada_nodo = aux.y;
                }
                if(coordenada_ponto < coordenada_nodo){

                    if(aux.esq == null){
                        aux.esq = p;
                        continua = false;
                    }else aux = aux.esq;

                }else{

                    if(aux.dir == null){
                        aux.dir = p;
                        continua = false;
                    }else aux = aux.dir;
                }
                nivel++;
            }
        }
    
    
    }

    @Override
    public String toString(){
        return "KD-tree { Raiz = " + raiz + " }";
    }   
}
