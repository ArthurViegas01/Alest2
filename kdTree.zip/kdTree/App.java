public class App {
    public static void main(String[] args) {
        KDtree kd = new KDtree();

        kd.AdicionarPonto("A", 800, 200);
        kd.AdicionarPonto("A", 600, 200);
        kd.AdicionarPonto("A", 820, 300);
        kd.AdicionarPonto("A", 900, 800);


        System.out.println(kd);




    }
}
